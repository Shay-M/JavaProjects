package shay.space.station.astrorobots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AstroRobotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AstroRobotsApplication.class, args);
	}

}
