package com.silverHorse.musicadvisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicAdvisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
